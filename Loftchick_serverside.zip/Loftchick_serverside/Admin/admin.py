import os
import sqlite3
import base64
from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# --- পাথ কনফিগারেশন (একদম ফিক্সড) ---
# এই ফাইলটা আছে Admin ফোল্ডারে, তাই এক ধাপ পেছনে গিয়ে products আর database ফোল্ডার খুঁজবো
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
DB_PATH = os.path.join(BASE_DIR, "database/loftchick.db")
UPLOAD_FOLDER = os.path.join(BASE_DIR, "products")

# Flask কে বলে দিচ্ছি ছবিগুলো কোথায় আছে
app.static_folder = UPLOAD_FOLDER
app.static_url_path = '/static/products'

# ফোল্ডার চেক ও তৈরি
os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS products 
                      (id INTEGER PRIMARY KEY AUTOINCREMENT, 
                       uid TEXT UNIQUE, 
                       name TEXT, 
                       price REAL, 
                       desc TEXT, 
                       stock INTEGER, 
                       images TEXT)''')
    conn.commit()
    conn.close()

@app.route('/add_product', methods=['POST'])
def add_product():
    data = request.json
    uid = data.get('uid')
    name = data.get('name')
    price = data.get('price')
    desc = data.get('desc')
    stock = data.get('stock')
    images_base64 = data.get('images', [])

    image_filenames = []
    for i, img_data in enumerate(images_base64):
        try:
            if "," in img_data:
                header, encoded = img_data.split(",", 1)
                # এক্সটেনশন বের করা (png, jpg, jpeg, etc.)
                ext = header.split("/")[1].split(";")[0]
                filename = f"{uid}_{i}.{ext}"
                filepath = os.path.join(UPLOAD_FOLDER, filename)
                with open(filepath, "wb") as f:
                    f.write(base64.b64decode(encoded))
                image_filenames.append(filename)
        except Exception as e:
            print(f"Error saving image: {e}")
            continue

    images_str = ",".join(image_filenames)

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('''INSERT OR REPLACE INTO products (uid, name, price, desc, stock, images) 
                      VALUES (?, ?, ?, ?, ?, ?)''', 
                   (uid, name, price, desc, stock, images_str))
    conn.commit()
    conn.close()
    return jsonify({"status": "success", "message": "Product saved with images!"})

@app.route('/get_products', methods=['GET'])
def get_products():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT uid, name, price, desc, stock, images FROM products")
    rows = cursor.fetchall()
    conn.close()
    
    products = []
    for r in rows:
        products.append({
            "uid": r[0], "name": r[1], "price": r[2], 
            "desc": r[3], "stock": r[4], "images": r[5] if r[5] else ""
        })
    return jsonify(products)

@app.route('/delete_product/<uid>', methods=['DELETE'])
def delete_product(uid):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM products WHERE uid=?", (uid,))
    conn.commit()
    conn.close()
    return jsonify({"status": "success", "message": "Deleted!"})

if __name__ == '__main__':
    init_db()
    print(f"✅ Server Started!")
    print(f"📂 Images Folder: {UPLOAD_FOLDER}")
    print(f"🔗 Static URL: /static/products")
    app.run(host='0.0.0.0', port=5000, debug=True)
