import os
import sqlite3
import random
import string
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from pyngrok import ngrok

app = Flask(__name__)
# CORS এবং Headers পুরোপুরি কনফিগার করা হয়েছে
CORS(app, resources={r"/*": {"origins": "*", "allow_headers": ["Content-Type", "ngrok-skip-browser-warning"]}})

# --- ১. এনগ্রক (ngrok) কনফিগারেশন ---
NGROK_AUTH_TOKEN = "2uqZpudiDf0hmJIkp4N5GxjUm8x_Wnx3MwywaqcVtfAgFSt3"
STATIC_DOMAIN = "strangely-exacting-delila.ngrok-free.dev"

try:
    ngrok.set_auth_token(NGROK_AUTH_TOKEN)
    public_url = ngrok.connect(5000, pyngrok_config=None, domain=STATIC_DOMAIN).public_url
    print(f"\n🚀 LoftChick Server is Live at: {public_url}")
except Exception as e:
    print(f"❌ ngrok Error: {e}")
    public_url = "http://127.0.0.1:5000"

# --- ২. পাথ সেটআপ ---
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PRODUCT_DIR = os.path.join(BASE_DIR, 'Products')
IMAGE_FOLDER = os.path.join(PRODUCT_DIR, 'Images')
DB_PATH = os.path.join(PRODUCT_DIR, 'products.db')

os.makedirs(IMAGE_FOLDER, exist_ok=True)

# --- ৩. ডেটাবেস ফাংশন ---
def init_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS products 
                      (uid TEXT PRIMARY KEY, name TEXT, price TEXT, desc TEXT, stock TEXT, images TEXT)''')
    conn.commit()
    conn.close()

init_db()

def generate_uid():
    return f"loftchickproduct_{''.join(random.choices(string.digits, k=3))}AFC"

# --- ৪. এপিআই রুটস ---

@app.route('/ping', methods=['GET'])
def ping():
    return jsonify({"status": "online"}), 200

@app.route('/get_products', methods=['GET'])
def get_products():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM products")
    rows = cursor.fetchall()
    conn.close()
    products = [{"uid": r[0], "name": r[1], "price": r[2], "desc": r[3], "stock": r[4], "images": r[5].split(",")} for r in rows]
    return jsonify(products)

@app.route('/add_product', methods=['POST'])
def add_product():
    try:
        uid = generate_uid()
        name = request.form.get('product_name')
        price = request.form.get('price')
        desc = request.form.get('description')
        stock = request.form.get('stock')
        files = request.files.getlist('images')

        saved_images = []
        for i, file in enumerate(files, start=1):
            if file:
                clean_name = name.replace(" ", "_")
                filename = f"images{i}_{clean_name}.jpeg"
                file.save(os.path.join(IMAGE_FOLDER, filename))
                saved_images.append(filename)

        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("INSERT INTO products VALUES (?, ?, ?, ?, ?, ?)", 
                       (uid, name, price, desc, stock, ",".join(saved_images)))
        conn.commit()
        conn.close()
        return jsonify({"status": "success", "uid": uid}), 201
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

# --- নতুন এডিট/আপডেট রুট ---
@app.route('/update_product/<uid>', methods=['PUT'])
def update_product(uid):
    data = request.json
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("UPDATE products SET name=?, price=?, desc=?, stock=? WHERE uid=?", 
                       (data['name'], data['price'], data['desc'], data['stock'], uid))
        conn.commit()
        conn.close()
        return jsonify({"status": "success", "message": "Updated successfully"}), 200
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/delete_product/<uid>', methods=['DELETE'])
def delete_product(uid):
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM products WHERE uid=?", (uid,))
        conn.commit()
        conn.close()
        return jsonify({"status": "success"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

if __name__ == '__main__':
    app.run(port=5000)
