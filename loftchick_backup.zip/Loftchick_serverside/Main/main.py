import os
import sys
from flask import Flask, jsonify, send_from_directory
from flask_cors import CORS
from pyngrok import ngrok

# ১. Product_Manager ফোল্ডারকে সিস্টেমে যোগ করা যাতে prod_man ইম্পোর্ট করা যায়
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PARENT_DIR = os.path.dirname(CURRENT_DIR)
sys.path.append(PARENT_DIR)

from Product_Manager.prod_man import get_all_products_from_db

app = Flask(__name__)

# ২. CORS কনফিগারেশন (যাতে ব্রাউজার থেকে রিকোয়েস্ট ব্লক না হয়)
CORS(app, resources={r"/*": {
    "origins": "*", 
    "allow_headers": ["Content-Type", "ngrok-skip-browser-warning"]
}})

# ৩. ইমেজের জন্য ডাইরেক্ট পাথ সেটআপ
IMAGE_FOLDER = os.path.join(PARENT_DIR, 'Products', 'Images')

# --- এনগ্রক (ngrok) সেটআপ ---
NGROK_AUTH_TOKEN = "2uqZpudiDf0hmJIkp4N5GxjUm8x_Wnx3MwywaqcVtfAgFSt3"

try:
    ngrok.set_auth_token(NGROK_AUTH_TOKEN)
    public_url = ngrok.connect(5001).public_url
    print(f"\n🌍 LoftChick Storefront API is Live at: {public_url}")
    print(f"👉 Use this URL in your index.html API_BASE_URL")
except Exception as e:
    print(f"❌ ngrok Error: {e}")

# --- এপিআই রুটস ---

@app.route('/api/products', methods=['GET'])
def get_products():
    # prod_man.py এর মাধ্যমে ডাটাবেস থেকে ডাটা আনা হচ্ছে
    data = get_all_products_from_db()
    return jsonify(data)

@app.route('/images/<filename>')
def serve_image(filename):
    # ডাইরেক্ট Products/Images ফোল্ডার থেকে ফাইল সার্ভ করা
    return send_from_directory(IMAGE_FOLDER, filename)

@app.route('/ping', methods=['GET'])
def ping():
    return jsonify({"status": "Main Hub Online"}), 200

if __name__ == '__main__':
    # ৫০০১ পোর্টে রান হচ্ছে
    app.run(port=5001)
