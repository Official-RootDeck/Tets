import sqlite3
import os

# ডিরেক্টরি পাথ সেটআপ
# এটি Loftchick_serverside/Products/products.db ফাইলটি খুঁজে নিবে
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, 'Products', 'products.db')

def get_all_products_from_db():
    """
    ডাটাবেস থেকে সব প্রোডাক্টের লিস্ট নিয়ে আসার মেইন ফাংশন।
    এটি main.py দ্বারা কল করা হবে।
    """
    try:
        # ডাটাবেস কানেকশন
        if not os.path.exists(DB_PATH):
            print(f"❌ Database not found at: {DB_PATH}")
            return []

        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        # সব ডাটা সিলেক্ট করা
        cursor.execute("SELECT * FROM products")
        rows = cursor.fetchall()
        conn.close()
        
        products = []
        for r in rows:
            # ডাটাবেসের রো গুলোকে ডিকশনারি ফরম্যাটে সাজানো
            # r[5] হলো ইমেজ কলাম যেখানে কমা দিয়ে নামগুলো থাকে
            products.append({
                "uid": r[0],
                "name": r[1],
                "price": r[2],
                "description": r[3],
                "stock": r[4],
                "images": r[5].split(",") if r[5] else [] 
            })
            
        return products
        
    except Exception as e:
        print(f"❌ Database Error in prod_man: {e}")
        return []

# টেস্টিং এর জন্য (অপশনাল)
if __name__ == "__main__":
    print(f"Checking Database at: {DB_PATH}")
    data = get_all_products_from_db()
    print(f"Total products found: {len(data)}")
